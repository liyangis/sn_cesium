<template>
  <div class="container">
    <div id="cesiumContainer"></div>
    <div class="measure">
      <ul>
        <li v-on:click="measureDistance">距离</li>
        <li>面积</li>
        <li>清除</li>
      </ul>
    </div>
  </div>
</template>

<script>
import Cesium from "cesium/Source/Cesium";
import Viewer from "cesium/Source/Widgets/Viewer/Viewer";
import buildModuleUrl from "cesium/Source/Core/buildModuleUrl";
import "cesium/Source/Widgets/widgets.css";
import MeasureDistance from "../modules/MeasureDistance";
import MeasureArea from "../modules/MeasureArea";
export default {
  name: "cesiumContainer",
  mounted: function() {
    buildModuleUrl.setBaseUrl("../static/cesium/");
    let opts = {
      animation: false, //是否显示动画控件
      baseLayerPicker: false, //是否显示图层选择控件
      geocoder: false, //是否显示地名查找控件
      timeline: false, //是否显示时间线控件
      sceneModePicker: false, //是否显示投影方式控件
      navigationHelpButton: false, //是否显示帮助信息控件
      infoBox: false, //是否显示点击要素之后显示的信息
      homeButton: false,
	  sceneModePicker: false,
	  selectionIndicator:false
    };
    this.viewer = new Viewer("cesiumContainer", opts);

    this.measureArea = new MeasureArea(this.viewer, false, {
      labelStyle: {
			pixelOffset : new Cesium.Cartesian2(0.0, 20),
			fillColor:new Cesium.Color(1, 1, 1, 1)
	  },
      lineStyle: {
        width: 1,
        material: Cesium.Color.BLUE
      },
      polyStyle: {
		hierarchy: {},
		outline : true,
        outlineColor : Cesium.Color.BLUE,
        outlineWidth : 1,
        material : Cesium.Color.fromRandom({alpha : 1.0})
      }
    });
  },
  data() {
    return {
      viewer: {}
    };
  },
  methods: {
    measureDistance: () => {
      this.measureDis = new MeasureDistance(
        this.viewer,
        false,
        {
          labelStyle: {},
          lineStyle: {
            width: 5,
            material: Cesium.Color.RED
          }
        },
        e => {}
      );
	},
	 measureArea: () => {
      this.measureArea = new MeasureDistance(
        this.viewer,
        false,
        {
          labelStyle: {},
          lineStyle: {
            width: 5,
            material: Cesium.Color.RED
          }
        },
        e => {}
      );
	},
	remove:function(){
		this.measureArea.remove();
		this.measureDis.remove();
	}
  }
};
</script>

<style scoped>
#cesiumContainer {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
.container {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
.measure {
  position: absolute;
  top: 1px;
  background-color: burlywood;
  width: 160px;
  height: 30px;
}
ul {
  margin: 0;
  padding: 0;
}
ul li {
  list-style-type: none;
  float: left;
  cursor: pointer;
  margin: 0px 3px;
}
</style>