<template>
    <div>
        <div class="nav">
            <ul>
                <li>
                    距离
                </li>
                <li>
                    面积
                </li>
            </ul>
        </div>
        <cesiumViewer></cesiumViewer>
    </div>
</template>
<script>
export default {
    name:"Measure",
    data(){
        return {
            
        }
    }
}
</script>
<style scoped>

</style>
